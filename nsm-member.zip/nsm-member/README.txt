NSM MEMBER CLUB - VERSION 2

1. แตก ZIP ไปไว้ที่ C:\xampp\htdocs\nsm-member\
2. เปิด XAMPP: Start Apache และ MySQL
3. เปิด http://localhost/phpmyadmin/
4. Import ไฟล์ sql/nsm_member_v2.sql
5. เปิด http://localhost/nsm-member/dashboard.php

สิ่งที่เพิ่มใน Version 2:
- งานสมาชิกกรอกข้อมูลรายเดือนตามโครงสร้าง Excel ปี 2569
- รองรับโครงสร้างปี 2568 สำหรับข้อมูลเปรียบเทียบ
- คำนวณรายได้จากจำนวน x ราคาอัตโนมัติ
- รายได้ Promotion / รักอ่านที่ Excel ให้กรอกเอง รองรับ revenue override
- NSM Member Club มีเป้าหมายรายปีแก้ไขได้ และระบบคำนวณเป้าหมายต่อเดือน = รายปี / 12
- เก็บประวัติการเปลี่ยนเป้าหมาย
- Dashboard ใช้ข้อมูลสมาชิกจริงจากตารางใหม่ และแสดงเทียบปีก่อน
- นำข้อมูลสมาชิก 2568 และ 2569 จาก Excel ที่ให้มาเข้าเป็นข้อมูลตั้งต้นแล้ว

หมายเหตุ:
- UI หลักยังใช้ sidebar/topbar/card/table จากระบบเดิม
- ถ้ามีฐานข้อมูลเดิมอยู่แล้ว แนะนำ backup ก่อน import SQL ใหม่
- สูตรและโครงสร้างปี 2568/2569 อ้างอิงจาก Excel ที่แนบมา


V5 notes:
- Member monthly entries preserve applied_rate when an existing month is edited.
- Comparison and dashboard revenue use applied_rate when available, so historical reports are protected from later price changes.


V14: ปรับงานสมาชิกให้รองรับรายละเอียดตาม Excel 2568/2569 ชัดเจนขึ้น แยกหัวข้อใหญ่/รายการย่อย และคงการตั้งราคา/สูตรไว้ที่ member_prices.php
