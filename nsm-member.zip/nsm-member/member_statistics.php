<?php
require_once __DIR__ . '/config/database.php';

$message = '';
$error = '';

$monthNames = [
    10 => 'ตุลาคม', 11 => 'พฤศจิกายน', 12 => 'ธันวาคม',
    1 => 'มกราคม', 2 => 'กุมภาพันธ์', 3 => 'มีนาคม',
    4 => 'เมษายน', 5 => 'พฤษภาคม', 6 => 'มิถุนายน',
    7 => 'กรกฎาคม', 8 => 'สิงหาคม', 9 => 'กันยายน'
];

$currentMonth = (int)date('n');
$currentYear  = (int)date('Y');
$defaultFY = ($currentMonth >= 10) ? $currentYear + 544 : $currentYear + 543;

$fy = isset($_GET['fy']) ? (int)$_GET['fy'] : $defaultFY;
$inputMonth = isset($_GET['month']) ? (int)$_GET['month'] : $currentMonth;
if (!isset($monthNames[$inputMonth])) $inputMonth = $currentMonth;

// ปีที่ใช้เปรียบเทียบในกราฟ/ตาราง เลือกได้อิสระทั้ง 2 ปี
$compareYear1 = isset($_GET['compare_year1']) ? (int)$_GET['compare_year1'] : ($fy - 1);
$compareYear2 = isset($_GET['compare_year2']) ? (int)$_GET['compare_year2'] : $fy;
if ($compareYear1 < 2500 || $compareYear1 > 2700) $compareYear1 = $fy - 1;
if ($compareYear2 < 2500 || $compareYear2 > 2700) $compareYear2 = $fy;

$availableYears = range($defaultFY, $defaultFY - 10, -1);
foreach ([$fy, $compareYear1, $compareYear2] as $extraYear) {
    if ($extraYear >= 2500 && $extraYear <= 2700 && !in_array($extraYear, $availableYears, true)) {
        $availableYears[] = $extraYear;
    }
}
sort($availableYears, SORT_NUMERIC);
$availableYears = array_reverse($availableYears);

// Migration สำหรับฐานข้อมูลเดิม: เพิ่ม applied_rate หากยังไม่มี
try {
    $col = $pdo->query("SHOW COLUMNS FROM member_monthly_entries LIKE 'applied_rate'")->fetch();
    if (!$col) {
        $pdo->exec("ALTER TABLE member_monthly_entries ADD COLUMN applied_rate DECIMAL(14,2) NOT NULL DEFAULT 0 AFTER revenue_override");
        $pdo->exec("UPDATE member_monthly_entries e INNER JOIN member_input_items i ON i.id=e.item_id SET e.applied_rate=i.rate WHERE e.applied_rate=0 AND i.calculation_type='fixed_rate'");
    }
} catch (Throwable $migrationEx) {
    // ปล่อยให้ระบบเดิมทำงานต่อ หากบัญชีฐานข้อมูลไม่มีสิทธิ์ ALTER
}

/* ปรับชื่อรายการ 2569 ให้ตรงกับ Excel โดยไม่เปลี่ยน item_code หรือข้อมูลย้อนหลัง */
try {
    $labelMigrations = [
        'mag_1y' => '1 ปี', 'mag_2y' => '2 ปี',
        'adult_1y' => '1 ปี', 'adult_2y' => '2 ปี',
        'family_1y' => '1 ปี', 'family_2y' => '2 ปี',
        'edu_no_future_1y' => 'ไม่รวม Futurium · 1 ปี',
        'edu_no_future_2y' => 'ไม่รวม Futurium · 2 ปี',
        'edu_future_1y' => 'รวม Futurium · 1 ปี',
        'edu_future_2y' => 'รวม Futurium · 2 ปี',
        'corporate' => 'รวมจำนวน', 'love_read' => 'รวมจำนวน',
        'street_child' => 'เด็ก', 'street_adult' => 'ผู้ใหญ่'
    ];
    $migrateStmt = $pdo->prepare('UPDATE member_input_items SET label=? WHERE fiscal_year=2569 AND item_code=?');
    foreach ($labelMigrations as $code=>$label) $migrateStmt->execute([$label,$code]);
} catch (Throwable $labelMigrationEx) {
    // ไม่ให้ migration นี้หยุดการทำงานของหน้าสมาชิก
}

function e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function money($value) { return '฿' . number_format((float)$value, 2); }
function pct($value) { return number_format((float)$value, 1) . '%'; }

function calculateRevenue($pdo, $fy, $month = null) {
    $sql = "SELECT COALESCE(SUM(CASE
                WHEN i.calculation_type = 'fixed_rate' THEN e.quantity * COALESCE(e.applied_rate, i.rate)
                WHEN i.calculation_type = 'manual_revenue' THEN COALESCE(e.revenue_override,0)
                ELSE 0 END),0)
            FROM member_monthly_entries e
            INNER JOIN member_input_items i ON i.id=e.item_id
            WHERE e.fiscal_year=?";
    $params = [$fy];
    if ($month !== null) { $sql .= ' AND e.fiscal_month=?'; $params[] = $month; }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (float)$stmt->fetchColumn();
}

function calculateMembers($pdo, $fy, $month = null) {
    $sql = 'SELECT COALESCE(SUM(quantity),0) FROM member_monthly_entries WHERE fiscal_year=?';
    $params = [$fy];
    if ($month !== null) { $sql .= ' AND fiscal_month=?'; $params[] = $month; }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

/* บันทึกข้อมูลสมาชิก */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_member_month') {
    $postFY = (int)($_POST['fiscal_year'] ?? $fy);
    $postMonth = (int)($_POST['fiscal_month'] ?? $inputMonth);
    $quantities = $_POST['quantity'] ?? [];
    $overrides = $_POST['revenue_override'] ?? [];
    $notes = trim($_POST['notes'] ?? '');

    if ($postFY < 2500 || $postFY > 2700) {
        $error = 'ปีงบประมาณไม่ถูกต้อง';
    } elseif (!isset($monthNames[$postMonth])) {
        $error = 'เดือนไม่ถูกต้อง';
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare('SELECT id, calculation_type FROM member_input_items WHERE fiscal_year=? AND is_active=1 ORDER BY sort_order');
            $stmt->execute([$postFY]);
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (!$items) throw new RuntimeException('ยังไม่มีรายการสมาชิกสำหรับปีงบประมาณนี้');

            $upsert = $pdo->prepare("INSERT INTO member_monthly_entries
                (fiscal_year,fiscal_month,item_id,quantity,revenue_override,applied_rate)
                VALUES (?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE quantity=VALUES(quantity), revenue_override=VALUES(revenue_override)");

            foreach ($items as $item) {
                $id = (int)$item['id'];
                $qty = max(0, (int)($quantities[$id] ?? 0));
                $override = null;
                $appliedRate = (float)$item['rate'];
                if ($item['calculation_type'] === 'manual_revenue') {
                    $raw = trim((string)($overrides[$id] ?? ''));
                    $override = ($raw === '') ? 0 : max(0, (float)$raw);
                }
                $upsert->execute([$postFY, $postMonth, $id, $qty, $override, $appliedRate]);
            }

            $noteStmt = $pdo->prepare("INSERT INTO member_monthly_notes(fiscal_year,fiscal_month,notes)
                VALUES(?,?,?) ON DUPLICATE KEY UPDATE notes=VALUES(notes)");
            $noteStmt->execute([$postFY, $postMonth, $notes]);

            $pdo->commit();
            $message = 'บันทึกข้อมูลสมาชิกประจำเดือนเรียบร้อยแล้ว';
            $fy = $postFY;
            $inputMonth = $postMonth;
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = 'ไม่สามารถบันทึกข้อมูลได้: ' . $ex->getMessage();
        }
    }
}

/* บันทึกเป้าหมาย NSM Member Club — เป้าหมายต่อเดือนคำนวณจากรายปีอัตโนมัติ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_target') {
    $targetFY = (int)($_POST['fiscal_year'] ?? $fy);
    $annual = max(0, (float)($_POST['annual_target'] ?? 0));

    try {
        $projectStmt = $pdo->prepare("SELECT id FROM projects WHERE name='NSM Member Club' LIMIT 1");
        $projectStmt->execute();
        $projectId = (int)$projectStmt->fetchColumn();
        if (!$projectId) throw new RuntimeException('ไม่พบโครงการ NSM Member Club');

        $monthly = $annual / 12;
        $oldStmt = $pdo->prepare('SELECT id,annual_target,monthly_target FROM revenue_targets WHERE fiscal_year=? AND project_id=? LIMIT 1');
        $oldStmt->execute([$targetFY,$projectId]);
        $old = $oldStmt->fetch(PDO::FETCH_ASSOC);

        if ($old) {
            $stmt = $pdo->prepare('UPDATE revenue_targets SET annual_target=?,monthly_target=? WHERE id=?');
            $stmt->execute([$annual,$monthly,$old['id']]);
            $targetId = (int)$old['id'];
            $oldAnnual = (float)$old['annual_target'];
            $oldMonthly = (float)$old['monthly_target'];
        } else {
            $stmt = $pdo->prepare('INSERT INTO revenue_targets(fiscal_year,project_id,annual_target,monthly_target) VALUES(?,?,?,?)');
            $stmt->execute([$targetFY,$projectId,$annual,$monthly]);
            $targetId = (int)$pdo->lastInsertId();
            $oldAnnual = null;
            $oldMonthly = null;
        }

        $history = $pdo->prepare('INSERT INTO revenue_target_history(revenue_target_id,fiscal_year,project_id,old_annual_target,new_annual_target,old_monthly_target,new_monthly_target) VALUES(?,?,?,?,?,?,?)');
        $history->execute([$targetId,$targetFY,$projectId,$oldAnnual,$annual,$oldMonthly,$monthly]);

        $fy = $targetFY;
        $message = 'บันทึกเป้าหมาย NSM Member Club เรียบร้อยแล้ว';
    } catch (Throwable $ex) {
        $error = 'ไม่สามารถบันทึกเป้าหมายได้: ' . $ex->getMessage();
    }
}

/* รายการสำหรับปีที่เลือก */
$stmt = $pdo->prepare('SELECT * FROM member_input_items WHERE fiscal_year=? AND is_active=1 ORDER BY category_code,sort_order,id');
$stmt->execute([$fy]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$entryStmt = $pdo->prepare('SELECT item_id,quantity,revenue_override,applied_rate FROM member_monthly_entries WHERE fiscal_year=? AND fiscal_month=?');
$entryStmt->execute([$fy,$inputMonth]);
$entryMap = [];
foreach ($entryStmt->fetchAll(PDO::FETCH_ASSOC) as $row) $entryMap[(int)$row['item_id']] = $row;

$noteStmt = $pdo->prepare('SELECT notes FROM member_monthly_notes WHERE fiscal_year=? AND fiscal_month=?');
$noteStmt->execute([$fy,$inputMonth]);
$monthNote = (string)($noteStmt->fetchColumn() ?: '');

$categories = [];
foreach ($items as $item) $categories[$item['category_code']][] = $item;

$categoryLabels = [];
foreach ($items as $item) $categoryLabels[$item['category_code']] = $item['category_name'];

/* เป้าหมาย NSM Member Club */
$projectStmt = $pdo->prepare("SELECT id,name FROM projects WHERE name='NSM Member Club' LIMIT 1");
$projectStmt->execute();
$project = $projectStmt->fetch(PDO::FETCH_ASSOC);
$projectId = (int)($project['id'] ?? 0);

$targetStmt = $pdo->prepare('SELECT id,annual_target,monthly_target FROM revenue_targets WHERE fiscal_year=? AND project_id=? LIMIT 1');
$targetStmt->execute([$fy,$projectId]);
$target = $targetStmt->fetch(PDO::FETCH_ASSOC) ?: ['id'=>0,'annual_target'=>0,'monthly_target'=>0];
$annualTarget = (float)$target['annual_target'];
$monthlyTarget = (float)$target['monthly_target'];

$monthRevenue = calculateRevenue($pdo,$fy,$inputMonth);
$yearRevenue = calculateRevenue($pdo,$fy);
$monthMembers = calculateMembers($pdo,$fy,$inputMonth);
$yearMembers = calculateMembers($pdo,$fy);

$prevFY = $fy - 1;
$prevYearRevenue = calculateRevenue($pdo,$prevFY);
$prevMonthRevenue = calculateRevenue($pdo,$prevFY,$inputMonth);
$yearDiff = $yearRevenue - $prevYearRevenue;
$yearDiffPct = $prevYearRevenue > 0 ? ($yearDiff/$prevYearRevenue)*100 : 0;
$achievement = $annualTarget > 0 ? ($yearRevenue/$annualTarget)*100 : 0;
$monthsElapsed = max(1, min(12, (int)$inputMonth));
$targetAccumulated = $monthlyTarget * $monthsElapsed;
$targetGap = $yearRevenue - $targetAccumulated;
$targetAccumulatedPct = $targetAccumulated > 0 ? ($yearRevenue / $targetAccumulated) * 100 : 0;
$remaining = max(0,$annualTarget-$yearRevenue);

// ข้อมูลสรุปสำหรับปีที่เลือกเปรียบเทียบ
$compareYear1Revenue = calculateRevenue($pdo, $compareYear1);
$compareYear2Revenue = calculateRevenue($pdo, $compareYear2);
$compareDiff = $compareYear2Revenue - $compareYear1Revenue;
$compareDiffPct = $compareYear1Revenue > 0 ? ($compareDiff / $compareYear1Revenue) * 100 : 0;

/* รายเดือน 12 เดือน สำหรับปีที่เลือกเปรียบเทียบ */
$monthly = [];
foreach ($monthNames as $m => $label) {
    $monthly[$m] = ['label'=>$label,'year1'=>0,'year2'=>0];
}
$sql = "SELECT e.fiscal_month, COALESCE(SUM(CASE
            WHEN i.calculation_type='fixed_rate'
                THEN e.quantity * COALESCE(NULLIF(e.applied_rate,0), i.rate)
            WHEN i.calculation_type='manual_revenue'
                THEN COALESCE(e.revenue_override,0)
            ELSE 0 END),0) revenue
        FROM member_monthly_entries e
        INNER JOIN member_input_items i ON i.id=e.item_id
        WHERE e.fiscal_year=? GROUP BY e.fiscal_month";
$stmt=$pdo->prepare($sql); $stmt->execute([$compareYear1]);
foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $m=(int)$r['fiscal_month'];
    if(isset($monthly[$m])) $monthly[$m]['year1']=(float)$r['revenue'];
}
$stmt=$pdo->prepare($sql); $stmt->execute([$compareYear2]);
foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $m=(int)$r['fiscal_month'];
    if(isset($monthly[$m])) $monthly[$m]['year2']=(float)$r['revenue'];
}

/* รายได้สะสมตามลำดับปีงบประมาณ ต.ค. -> ก.ย. */
$orderedMonths=[10,11,12,1,2,3,4,5,6,7,8,9];
$cumYear1=0; $cumYear2=0; $chart=[];
foreach($orderedMonths as $m){
    $cumYear1 += $monthly[$m]['year1'];
    $cumYear2 += $monthly[$m]['year2'];
    $chart[]=[
        'label'=>$monthly[$m]['label'],
        'year1'=>$monthly[$m]['year1'],
        'year2'=>$monthly[$m]['year2'],
        'cumulativeYear1'=>$cumYear1,
        'cumulativeYear2'=>$cumYear2
    ];
}

/* ประวัติเป้าหมาย */
$history=[];
if($projectId){
    $h=$pdo->prepare('SELECT old_annual_target,new_annual_target,changed_at FROM revenue_target_history WHERE fiscal_year=? AND project_id=? ORDER BY changed_at DESC,id DESC LIMIT 8');
    $h->execute([$fy,$projectId]); $history=$h->fetchAll(PDO::FETCH_ASSOC);
}

$dashboardLabels=json_encode(array_column($chart,'label'),JSON_UNESCAPED_UNICODE);
$dashboardYear1=json_encode(array_column($chart,'year1'));
$dashboardYear2=json_encode(array_column($chart,'year2'));
$dashboardTarget=json_encode(array_fill(0,12,$monthlyTarget));
?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>งานสมาชิก - NSM Member Club</title>
<link rel="stylesheet" href="assets/css/style.css">
<style>
.page-card{background:#fff;border:1px solid #e7ebef;border-radius:14px;padding:20px;margin-bottom:20px}.page-title{font-size:16px;font-weight:700}.page-subtitle{font-size:11px;color:#8a96a3;margin-top:3px;margin-bottom:18px}.form-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}.form-group{display:flex;flex-direction:column;gap:7px}.form-group label{font-size:13px;font-weight:600}.form-group input,.form-group select,.form-group textarea{border:1px solid #d9e0e7;background:#fff;border-radius:8px;padding:9px 12px;font-size:13px}.form-group textarea{min-height:90px;resize:vertical}.full{grid-column:1/-1}.filter-bar{margin-bottom:20px}.btn{border:0;border-radius:8px;padding:9px 14px;cursor:pointer;font-size:13px;font-weight:600}.btn-primary{background:#2f80ed;color:#fff}.btn-secondary{background:#edf1f5;color:#34495e}.btn-green{background:#198754;color:#fff}.form-actions{display:flex;gap:10px;margin-top:18px}.message{padding:12px 15px;border-radius:10px;background:#e9f8ef;color:#198754;margin-bottom:18px;font-size:13px}.error{padding:12px 15px;border-radius:10px;background:#fff0f0;color:#b42318;margin-bottom:18px;font-size:13px}.member-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:18px}.member-box{border:1px solid #e7ebef;border-radius:12px;padding:16px}.member-box h3{font-size:14px;margin-bottom:12px}.input-row{display:grid;grid-template-columns:1fr 130px 130px;gap:8px;align-items:center;padding:8px 0;border-bottom:1px solid #f1f3f5}.input-row:last-child{border-bottom:0}.input-label{font-size:12px}.rate{font-size:11px;color:#8a96a3}.input-row input{width:100%;border:1px solid #d9e0e7;border-radius:7px;padding:8px;font-size:12px;text-align:right}.calc{font-size:12px;text-align:right;font-weight:600}.manual-label{font-size:11px;color:#8a96a3;margin-top:12px}.summary-mini{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}.mini{border:1px solid #e7ebef;border-radius:10px;padding:14px}.mini-label{font-size:11px;color:#8a96a3}.mini-value{font-size:20px;font-weight:700;margin-top:3px}.target-panel{display:grid;grid-template-columns:1.3fr 1fr;gap:20px;align-items:center}.target-big{font-size:30px;font-weight:700}.progress{height:12px;background:#edf1f5;border-radius:10px;overflow:hidden;margin:15px 0 8px}.progress-bar{height:100%;background:#2f80ed;border-radius:10px}.target-row{display:flex;justify-content:space-between;font-size:12px;color:#6b7280;margin-top:9px}.target-form{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end}.target-form input{width:100%;border:1px solid #d9e0e7;border-radius:8px;padding:10px}.target-note{font-size:11px;color:#8a96a3;margin-top:7px}.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse}th,td{padding:10px 9px;border-bottom:1px solid #eef1f4;text-align:left;font-size:12px}th{color:#7b8794;background:#f8fafc}.right{text-align:right}.positive{color:#159957}.negative{color:#dc3545}.chart-container{height:300px}.compare-form{margin:0 0 18px}.compare-selects{display:flex;align-items:end;gap:12px;flex-wrap:wrap}.compare-field{display:flex;flex-direction:column;gap:6px;min-width:150px}.compare-field label{font-size:12px;font-weight:600;color:#34495e}.compare-field select{border:1px solid #d9e0e7;background:#fff;border-radius:8px;padding:9px 12px;font-size:13px}.compare-vs{font-size:12px;font-weight:700;color:#8a96a3;padding-bottom:10px}.tag{display:inline-block;padding:4px 8px;border-radius:20px;background:#eaf3ff;color:#2f80ed;font-size:10px}.history td{font-size:11px}@media(max-width:900px){.member-grid,.target-panel,.form-grid{grid-template-columns:1fr}.summary-mini{grid-template-columns:repeat(2,1fr)}}@media(max-width:600px){.summary-mini{grid-template-columns:1fr}.input-row{grid-template-columns:1fr 90px}.calc{grid-column:2}.target-form{grid-template-columns:1fr}}
</style>
</head>
<body>
<aside class="sidebar">
<div class="brand"><div class="brand-icon">👥</div><div><div class="brand-title">NSM Member Club</div><div class="brand-subtitle">Management System</div></div></div>
<nav class="menu"><div class="menu-label">MAIN MENU</div>
<a href="dashboard.php">🏠 <span>Dashboard</span></a>
<a class="active" href="member_statistics.php">👥 <span>งานสมาชิก</span></a>
<a href="employees.php">👨‍💼 <span>งานพนักงาน</span></a>
<a href="member_prices.php">💰 <span>ราคาสมาชิก</span></a>
<a href="#">📊 <span>รายงาน</span></a><a href="#">🏆 <span>ผลงาน / KPI</span></a>
<div class="menu-label system">SYSTEM</div><a href="settings.php">⚙️ <span>ตั้งค่าระบบ</span></a>
</nav></aside>
<main class="main"><header class="topbar"><div><h1>งานสมาชิก</h1><p>บันทึกข้อมูลสมาชิกและติดตามเป้าหมายรายได้ NSM Member Club</p></div><div class="top-actions"><button class="icon-button">🔔</button><div class="avatar">A</div></div></header>
<section class="content">
<?php if($message): ?><div class="message"><?=e($message)?></div><?php endif; ?>
<?php if($error): ?><div class="error"><?=e($error)?></div><?php endif; ?>

<div class="filter-bar"><span class="filter-label">ปีงบประมาณ</span><form method="get" style="display:flex;gap:10px;flex-wrap:wrap"><select name="fy" onchange="this.form.submit()"><?php for($y=$defaultFY;$y>=$defaultFY-5;$y--): ?><option value="<?=$y?>" <?=$fy===$y?'selected':''?>><?=$y?></option><?php endfor; ?></select><span class="filter-label" style="align-self:center">เดือน</span><select name="month" onchange="this.form.submit()"><?php foreach($monthNames as $m=>$label): ?><option value="<?=$m?>" <?=$inputMonth===$m?'selected':''?>><?=$label?></option><?php endforeach; ?></select></form></div>

<div class="summary-mini">
<div class="mini"><div class="mini-label">สมาชิกเดือนนี้</div><div class="mini-value"><?=number_format($monthMembers)?></div></div>
<div class="mini"><div class="mini-label">รายได้เดือนนี้</div><div class="mini-value"><?=money($monthRevenue)?></div></div>
<div class="mini"><div class="mini-label">รายได้สะสม</div><div class="mini-value"><?=money($yearRevenue)?></div></div>
<div class="mini"><div class="mini-label"><?=$compareYear1?> → <?=$compareYear2?></div><div class="mini-value <?=($compareDiff>=0?'positive':'negative')?>"><?=($compareDiff>=0?'+':'')?><?=money($compareDiff)?></div></div>
</div>

<div class="page-card">
<div class="page-title">📝 กรอกข้อมูลสมาชิก — <?=$monthNames[$inputMonth]?> ปีงบประมาณ <?=$fy?></div>
<div class="page-subtitle">กรอกเฉพาะจำนวนสมาชิกและรายได้ที่ต้องระบุเอง ระบบจะคำนวณรายได้จากราคาให้โดยอัตโนมัติ</div>
<form method="post"><input type="hidden" name="action" value="save_member_month"><input type="hidden" name="fiscal_year" value="<?=$fy?>"><input type="hidden" name="fiscal_month" value="<?=$inputMonth?>">
<div class="member-grid">
<?php foreach($categories as $cat=>$catItems): ?>
<div class="member-box">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:12px">
        <div><h3 style="margin-bottom:3px"><?=e($categoryLabels[$cat])?></h3>
        <div class="rate">กรอกจำนวนตามรายการย่อยของ Excel</div></div>
        <span class="tag"><?=count($catItems)?> รายการ</span>
    </div>
<?php foreach($catItems as $item): $id=(int)$item['id'];$entry=$entryMap[$id]??[];$q=(int)($entry['quantity']??0);$ov=$entry['revenue_override']??''; ?>
<div class="input-row">
    <div><div class="input-label"><?=e($item['label'])?></div>
    <?php if((float)$item['rate']>0): ?><div class="rate">ราคา <?=money($item['rate'])?> / ราย</div>
    <?php elseif($item['calculation_type']==='manual_revenue'): ?><div class="rate">รายได้กรอกเอง</div>
    <?php else: ?><div class="rate">นับจำนวน · ไม่มีรายได้</div><?php endif; ?>
    </div>
    <input type="number" name="quantity[<?=$id?>]" value="<?=$q?>" min="0" step="1" aria-label="<?=e($item['category_name'].' '.$item['label'])?>">
    <div class="calc" data-rate="<?=e($item['rate'])?>" data-type="<?=e($item['calculation_type'])?>" data-override="<?=e($ov)?>">-</div>
</div>
<?php if($item['calculation_type']==='manual_revenue'): ?>
<div class="manual-label">รายได้ <?=e($item['category_name'].' '.$item['label'])?> (บาท)</div>
<input type="number" name="revenue_override[<?=$id?>]" value="<?=e($ov)?>" min="0" step="0.01" style="width:100%;border:1px solid #d9e0e7;border-radius:7px;padding:8px;text-align:right">
<?php endif; ?>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
</div>
<div class="form-grid" style="margin-top:18px"><div class="form-group full"><label>หมายเหตุประจำเดือน</label><textarea name="notes" placeholder="เช่น ชื่องาน / โปรโมชั่น / รายละเอียด Complimentary / หมายเหตุอื่น ๆ"><?=e($monthNote)?></textarea></div></div>
<div class="form-actions"><button class="btn btn-primary" type="submit">💾 บันทึกข้อมูลเดือนนี้</button></div></form></div>

<div class="page-card" style="padding:14px 18px;">
<div class="page-subtitle" style="margin:0;"><strong>โครงสร้างข้อมูล:</strong> ระบบรองรับหัวข้อใหญ่และรายการย่อยหลายรายการ เช่น นิตยสาร, บัตรผู้ใหญ่, บัตรครอบครัว, บัตรสถาบันการศึกษา (รวม/ไม่รวม Futurium), Promotion, Complimentary, Corporate, รักอ่าน และ The Street โดยรายการและราคาสามารถแตกต่างกันตามปีงบประมาณ</div>
</div>

<div class="page-card" id="target">
<div class="page-title">🎯 เป้าหมายรายได้จากโครงการ NSM Member Club</div>
<div class="page-subtitle">เป้าหมายรายปีสามารถเปลี่ยนแปลงได้ตามนโยบายบริษัท และระบบคำนวณเป้าหมายเฉลี่ยรายเดือนจากเป้าหมายรายปี ÷ 12</div>
<div class="summary-mini" style="margin-top:16px;">
<div class="mini"><div class="mini-label">เป้าหมายเฉลี่ยรายเดือน</div><div class="mini-value"><?=money($monthlyTarget)?></div></div>
<div class="mini"><div class="mini-label">เป้าหมายสะสมถึงเดือนนี้</div><div class="mini-value"><?=money($targetAccumulated)?></div></div>
<div class="mini"><div class="mini-label">ส่วนต่างเทียบกับเป้าหมาย</div><div class="mini-value <?=($targetGap>=0?'positive':'negative')?>"><?=($targetGap>=0?'+':'')?><?=money($targetGap)?></div></div>
<div class="mini"><div class="mini-label">ร้อยละรายได้สะสมเทียบกับเป้าหมาย</div><div class="mini-value <?=($targetAccumulatedPct>=100?'positive':'negative')?>"><?=pct($targetAccumulatedPct)?></div></div>
</div>
<div class="target-panel"><div><div class="target-big"><?=money($annualTarget)?></div><div class="target-note">เป้าหมายรายปี · ปีงบประมาณ <?=$fy?></div><div class="progress"><div class="progress-bar" style="width:<?=min(100,max(0,$achievement))?>%"></div></div><div class="target-row"><span>รายได้สะสม <?=money($yearRevenue)?></span><strong><?=pct($achievement)?> ของเป้าหมายทั้งปี</strong></div><div class="target-row"><span>เหลือจากเป้าหมายทั้งปี</span><strong><?=money($remaining)?></strong></div></div>
<div><form method="post" class="target-form"><input type="hidden" name="action" value="save_target"><input type="hidden" name="fiscal_year" value="<?=$fy?>"><div><label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px">เป้าหมายรายปี (บาท)</label><input type="number" name="annual_target" value="<?=e($annualTarget)?>" min="0" step="0.01" required><div class="target-note">เป้าหมายเฉลี่ยรายเดือน: <?=money($monthlyTarget)?></div></div><button class="btn btn-primary" type="submit">💾 บันทึกเป้าหมาย</button></form></div></div>
</div>

<div class="grid"><div class="card"><div class="card-header"><div><div class="card-title">📈 เปรียบเทียบรายได้สมาชิก</div><div class="card-subtitle">เลือกปีที่ต้องการเปรียบเทียบได้อิสระ</div></div><span class="tag">NSM Member Club</span></div>
<form method="get" class="compare-form">
<input type="hidden" name="fy" value="<?=e($fy)?>">
<input type="hidden" name="month" value="<?=e($inputMonth)?>">
<div class="compare-selects">
<div class="compare-field"><label>ปีที่ 1</label><select name="compare_year1" onchange="this.form.submit()"><?php foreach($availableYears as $y): ?><option value="<?=$y?>" <?=$compareYear1===$y?'selected':''?>><?=$y?></option><?php endforeach; ?></select></div>
<div class="compare-vs">VS</div>
<div class="compare-field"><label>ปีที่ 2</label><select name="compare_year2" onchange="this.form.submit()"><?php foreach($availableYears as $y): ?><option value="<?=$y?>" <?=$compareYear2===$y?'selected':''?>><?=$y?></option><?php endforeach; ?></select></div>
</div>
</form>
<div class="chart-container"><canvas id="memberRevenueChart"></canvas></div></div>
<div class="card"><div class="card-header"><div><div class="card-title">📊 สรุปเป้าหมาย</div><div class="card-subtitle">เป้าหมายปี <?=$fy?> เทียบรายได้สะสม</div></div></div><div class="target-number"><?=pct($achievement)?></div><div class="target-text">ความสำเร็จของเป้าหมาย <?=money($annualTarget)?></div><div class="progress"><div class="progress-bar" style="width:<?=min(100,max(0,$achievement))?>%"></div></div><div class="target-row"><span>ปี <?=$fy?></span><strong><?=money($yearRevenue)?></strong></div><div class="target-row"><span>เปรียบเทียบ <?=$compareYear1?> → <?=$compareYear2?></span><strong class="<?=($compareDiff>=0?'positive':'negative')?>"><?=($compareDiff>=0?'+':'')?><?=pct($compareDiffPct)?></strong></div><div class="target-row"><span>รายได้ <?=$compareYear1?></span><strong><?=money($compareYear1Revenue)?></strong></div><div class="target-row"><span>รายได้ <?=$compareYear2?></span><strong><?=money($compareYear2Revenue)?></strong></div></div></div>

<div class="page-card"><div class="page-title">📋 ตารางเปรียบเทียบรายเดือน</div><div class="page-subtitle">รายได้จริงและรายได้สะสมของปีที่เลือก</div><div class="table-wrap"><table><thead><tr><th>เดือน</th><th class="right">ปี <?=$compareYear1?></th><th class="right">สะสม <?=$compareYear1?></th><th class="right">ปี <?=$compareYear2?></th><th class="right">สะสม <?=$compareYear2?></th><th class="right">ต่างกัน</th></tr></thead><tbody><?php foreach($chart as $r): $d=$r['year2']-$r['year1']; ?><tr><td><?=e($r['label'])?></td><td class="right"><?=money($r['year1'])?></td><td class="right"><?=money($r['cumulativeYear1'])?></td><td class="right"><?=money($r['year2'])?></td><td class="right"><?=money($r['cumulativeYear2'])?></td><td class="right <?=($d>=0?'positive':'negative')?>"><?=($d>=0?'+':'')?><?=money($d)?></td></tr><?php endforeach; ?></tbody></table></div></div>

<?php if($history): ?><div class="page-card history"><div class="page-title">🕘 ประวัติการเปลี่ยนเป้าหมาย</div><div class="page-subtitle">เก็บย้อนหลังเพื่อให้ตรวจสอบได้ว่าบริษัทปรับเป้าหมายเมื่อใด</div><div class="table-wrap"><table><thead><tr><th>วันที่</th><th class="right">เป้าหมายเดิม</th><th class="right">เป้าหมายใหม่</th><th class="right">เปลี่ยนแปลง</th></tr></thead><tbody><?php foreach($history as $h): $diff=(float)$h['new_annual_target']-(float)($h['old_annual_target']??0); ?><tr><td><?=e(date('d/m/Y H:i',strtotime($h['changed_at'])))?></td><td class="right"><?=is_null($h['old_annual_target'])?'-':money($h['old_annual_target'])?></td><td class="right"><?=money($h['new_annual_target'])?></td><td class="right <?=($diff>=0?'positive':'negative')?>"><?=($diff>=0?'+':'')?><?=money($diff)?></td></tr><?php endforeach; ?></tbody></table></div></div><?php endif; ?>
<div class="footer">NSM Member Club Management System · Member Statistics</div>
</section></main>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const labels=<?=$dashboardLabels?>, year1Data=<?=$dashboardYear1?>, year2Data=<?=$dashboardYear2?>, target=<?=$dashboardTarget?>;
const c=document.getElementById('memberRevenueChart');
if(c&&typeof Chart!=='undefined'){new Chart(c.getContext('2d'),{type:'line',data:{labels,datasets:[{label:'รายได้ปี <?=$compareYear1?>',data:year1Data,borderWidth:3,tension:.35,fill:false},{label:'รายได้ปี <?=$compareYear2?>',data:year2Data,borderWidth:3,tension:.35,fill:false},{label:'เป้าหมาย/เดือน ปี <?=$fy?>',data:target,borderWidth:2,borderDash:[3,4],fill:false}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:x=>x.dataset.label+': ฿'+Number(x.raw||0).toLocaleString('th-TH')}}},scales:{y:{beginAtZero:true,ticks:{callback:v=>'฿'+Number(v).toLocaleString('th-TH')}}}}});}
function refreshCalc(){document.querySelectorAll('.input-row').forEach(row=>{const input=row.querySelector('input[type=number]');const out=row.querySelector('.calc');if(!input||!out)return;const rate=parseFloat(out.dataset.rate||0);const type=out.dataset.type;if(type==='fixed_rate')out.textContent='฿'+((parseFloat(input.value)||0)*rate).toLocaleString('th-TH',{minimumFractionDigits:2,maximumFractionDigits:2});else if(type==='zero_revenue')out.textContent='฿0.00';else out.textContent='กรอกเอง';});}
document.querySelectorAll('.input-row input').forEach(x=>x.addEventListener('input',refreshCalc));refreshCalc();
</script>
</body></html>
