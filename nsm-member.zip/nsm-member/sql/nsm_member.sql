CREATE DATABASE IF NOT EXISTS nsm_member CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nsm_member;
CREATE TABLE IF NOT EXISTS buildings(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,is_active TINYINT(1) DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS positions(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,is_active TINYINT(1) DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS employees(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,is_active TINYINT(1) DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS employee_work_records(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,work_date DATE NOT NULL,employee_id INT UNSIGNED NOT NULL,employee_name_snapshot VARCHAR(150) NOT NULL,position_id INT UNSIGNED NULL,position_snapshot VARCHAR(150) NULL,building_id INT UNSIGNED NULL,building_snapshot VARCHAR(150) NULL,member_notifications INT UNSIGNED DEFAULT 0,daily_sales DECIMAL(12,2) DEFAULT 0,notes TEXT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(work_date),INDEX(employee_id),INDEX(building_id));
CREATE TABLE IF NOT EXISTS projects(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(200) NOT NULL,is_active TINYINT(1) DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS revenue_targets(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,fiscal_year SMALLINT UNSIGNED NOT NULL,project_id INT UNSIGNED NOT NULL,annual_target DECIMAL(14,2) NOT NULL DEFAULT 0,monthly_target DECIMAL(14,2) NOT NULL DEFAULT 0,UNIQUE KEY uq_year_project(fiscal_year,project_id));
CREATE TABLE IF NOT EXISTS member_statistics(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,fiscal_year SMALLINT UNSIGNED NOT NULL,fiscal_month TINYINT UNSIGNED NOT NULL,member_type VARCHAR(100) NOT NULL,member_count INT UNSIGNED DEFAULT 0,revenue DECIMAL(14,2) DEFAULT 0,notes TEXT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(fiscal_year,fiscal_month));
INSERT INTO buildings(name) SELECT 'อาคารพระจอมเกล้า' WHERE NOT EXISTS(SELECT 1 FROM buildings WHERE name='อาคารพระจอมเกล้า');
INSERT INTO buildings(name) SELECT 'อาคารพิพิธภัณฑ์' WHERE NOT EXISTS(SELECT 1 FROM buildings WHERE name='อาคารพิพิธภัณฑ์');
INSERT INTO buildings(name) SELECT 'อาคารปฏิบัติการ' WHERE NOT EXISTS(SELECT 1 FROM buildings WHERE name='อาคารปฏิบัติการ');
INSERT INTO positions(name) SELECT 'เจ้าหน้าที่สมาชิก' WHERE NOT EXISTS(SELECT 1 FROM positions WHERE name='เจ้าหน้าที่สมาชิก');
INSERT INTO positions(name) SELECT 'เจ้าหน้าที่โครงการ' WHERE NOT EXISTS(SELECT 1 FROM positions WHERE name='เจ้าหน้าที่โครงการ');
INSERT INTO projects(name) SELECT 'NSM Member Club' WHERE NOT EXISTS(SELECT 1 FROM projects WHERE name='NSM Member Club');
INSERT INTO revenue_targets(fiscal_year,project_id,annual_target,monthly_target)
SELECT 2569,id,6000000,500000 FROM projects WHERE name='NSM Member Club'
AND NOT EXISTS(SELECT 1 FROM revenue_targets r WHERE r.fiscal_year=2569 AND r.project_id=projects.id);