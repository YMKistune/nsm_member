<?php
require_once __DIR__ . '/config/database.php';

/*
|--------------------------------------------------------------------------
| ตั้งค่าปีงบประมาณ
|--------------------------------------------------------------------------
*/
$fy = $_GET['fy'] ?? '2569';
$fy = (int)$fy;

/*
|--------------------------------------------------------------------------
| แปลงปีงบประมาณ พ.ศ. เป็น ค.ศ.
| เช่น 2569 -> 2026
|--------------------------------------------------------------------------
*/
$calendarYear = $fy - 543;


/*
|--------------------------------------------------------------------------
| ข้อมูลสมาชิกจากโครงสร้างใหม่
|--------------------------------------------------------------------------
*/
$fy = isset($_GET['fy']) ? (int)$_GET['fy'] : 2569;
$calendarYear = $fy - 543;
$prevFY = $fy - 1;

$revenueSql = "SELECT COALESCE(SUM(CASE
    WHEN i.calculation_type='fixed_rate' THEN e.quantity*COALESCE(NULLIF(e.applied_rate,0),i.rate)
    WHEN i.calculation_type='manual_revenue' THEN COALESCE(e.revenue_override,0)
    ELSE 0 END),0)
    FROM member_monthly_entries e
    INNER JOIN member_input_items i ON i.id=e.item_id
    WHERE e.fiscal_year=?";

$stmt=$pdo->prepare('SELECT COALESCE(SUM(quantity),0) FROM member_monthly_entries WHERE fiscal_year=?');
$stmt->execute([$fy]);
$members=(int)$stmt->fetchColumn();

$stmt=$pdo->prepare($revenueSql);
$stmt->execute([$fy]);
$revenue=(float)$stmt->fetchColumn();

$stmt=$pdo->prepare("SELECT COALESCE(SUM(annual_target),0) annual_target, COALESCE(SUM(monthly_target),0) monthly_target FROM revenue_targets WHERE fiscal_year=?");
$stmt->execute([$fy]);
$targetData=$stmt->fetch(PDO::FETCH_ASSOC);
$target=(float)($targetData['annual_target']??0);
$monthly_target=(float)($targetData['monthly_target']??0);

$achievement=$target>0?($revenue/$target)*100:0;
$remaining=max(0,$target-$revenue);

$stmt=$pdo->prepare("SELECT COALESCE(SUM(member_notifications),0) FROM employee_work_records WHERE YEAR(work_date)=?");
$stmt->execute([$calendarYear]);
$notifications=(int)$stmt->fetchColumn();

$stmt=$pdo->prepare("SELECT COUNT(*) FROM employee_work_records WHERE YEAR(work_date)=?");
$stmt->execute([$calendarYear]);
$work_count=(int)$stmt->fetchColumn();

$orderedMonths=[10,11,12,1,2,3,4,5,6,7,8,9];
$labels=['ตุลาคม','พฤศจิกายน','ธันวาคม','มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน'];
$actual=array_fill(0,12,0);
$previous=array_fill(0,12,0);

$monthlySql="SELECT fiscal_month, COALESCE(SUM(CASE WHEN i.calculation_type='fixed_rate' THEN e.quantity*COALESCE(NULLIF(e.applied_rate,0),i.rate) WHEN i.calculation_type='manual_revenue' THEN COALESCE(e.revenue_override,0) ELSE 0 END),0) revenue
FROM member_monthly_entries e INNER JOIN member_input_items i ON i.id=e.item_id WHERE e.fiscal_year=? GROUP BY fiscal_month";
$stmt=$pdo->prepare($monthlySql);$stmt->execute([$fy]);
$map=[];foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $r)$map[(int)$r['fiscal_month']] = (float)$r['revenue'];
foreach($orderedMonths as $i=>$m)$actual[$i]=$map[$m]??0;
$stmt=$pdo->prepare($monthlySql);$stmt->execute([$prevFY]);
$map=[];foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $r)$map[(int)$r['fiscal_month']] = (float)$r['revenue'];
foreach($orderedMonths as $i=>$m)$previous[$i]=$map[$m]??0;
$targetChart=array_fill(0,12,$monthly_target);

/*
|--------------------------------------------------------------------------
| 7. ผลงานพนักงาน
|--------------------------------------------------------------------------
*/

$employees = [];

$stmt = $pdo->prepare("
    SELECT
        e.id,
        e.name,

        COALESCE(
            (
                SELECT p.name
                FROM employee_work_records wr
                LEFT JOIN positions p
                    ON p.id = wr.position_id
                WHERE wr.employee_id = e.id
                ORDER BY wr.work_date DESC, wr.id DESC
                LIMIT 1
            ),
            '-'
        ) AS position_name,

        COALESCE(SUM(w.daily_sales), 0) AS revenue,

        COUNT(w.id) AS work_count,

        COALESCE(
            SUM(w.member_notifications),
            0
        ) AS notifications

    FROM employees e

    LEFT JOIN employee_work_records w
        ON w.employee_id = e.id
        AND YEAR(w.work_date) = ?

    WHERE e.is_active = 1

    GROUP BY e.id, e.name

    HAVING work_count > 0

    ORDER BY revenue DESC

    LIMIT 4
");

$stmt->execute([$calendarYear]);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

    $employees[] = [
        $row['name'],
        $row['position_name'],
        (float)$row['revenue'],
        (int)$row['work_count'],
        (int)$row['notifications']
    ];
}


/*
|--------------------------------------------------------------------------
| 8. ผลงานตามอาคาร
|--------------------------------------------------------------------------
*/

$buildings = [];

$stmt = $pdo->prepare("
    SELECT
        b.id,
        b.name,

        COUNT(w.id) AS work_count,

        COALESCE(
            SUM(w.daily_sales),
            0
        ) AS revenue

    FROM buildings b

    LEFT JOIN employee_work_records w
        ON w.building_id = b.id
        AND YEAR(w.work_date) = ?

    WHERE b.is_active = 1

    GROUP BY b.id, b.name

    ORDER BY revenue DESC
");

$stmt->execute([$calendarYear]);

$buildingRows = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| หาอาคารที่มีรายได้สูงสุด
|--------------------------------------------------------------------------
*/

$maxBuildingRevenue = 0;

foreach ($buildingRows as $row) {

    $maxBuildingRevenue = max(
        $maxBuildingRevenue,
        (float)$row['revenue']
    );
}


/*
|--------------------------------------------------------------------------
| เตรียมข้อมูลอาคารสำหรับ HTML
|--------------------------------------------------------------------------
*/

foreach ($buildingRows as $row) {

    $buildingRevenue = (float)$row['revenue'];

    $isHighest =
        $maxBuildingRevenue > 0 &&
        $buildingRevenue == $maxBuildingRevenue;

    $buildings[] = [
        $row['name'],
        (int)$row['work_count'],
        $buildingRevenue,
        $isHighest
    ];
}


/*
|--------------------------------------------------------------------------
| รวมข้อมูล Dashboard
|--------------------------------------------------------------------------
*/

$d = [
    'members'       => $members,
    'revenue'       => $revenue,
    'work_count'    => $work_count,
    'notifications' => $notifications,
    'target'        => $target,
    'achievement'   => $achievement,
    'remaining'     => $remaining
];


/*
|--------------------------------------------------------------------------
| ฟังก์ชันแสดงเงิน
|--------------------------------------------------------------------------
*/

function money($v)
{
    return '฿' . number_format($v);
}

?>
<!doctype html>

<html lang="th">

<head>

<meta charset="utf-8">

<meta
    name="viewport"
    content="width=device-width,initial-scale=1"
>

<title>NSM Member Club - Dashboard</title>

<link
    rel="stylesheet"
    href="assets/css/style.css"
>

<script
    src="https://cdn.jsdelivr.net/npm/chart.js"
></script>

</head>

<body>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<aside class="sidebar">

    <div class="brand">

        <div class="brand-icon">
            👥
        </div>

        <div>

            <div class="brand-title">
                NSM Member Club
            </div>

            <div class="brand-subtitle">
                Management System
            </div>

        </div>

    </div>


    <nav class="menu">

        <div class="menu-label">
            MAIN MENU
        </div>


        <a
            class="active"
            href="dashboard.php"
        >
            🏠
            <span>Dashboard</span>
        </a>


        <a href="member_statistics.php">
            👥
            <span>งานสมาชิก</span>
        </a>


        <a href="employees.php">
            👨‍💼
            <span>งานพนักงาน</span>
        </a>


        <a href="#">
            🎯
            <span>เป้าหมายรายได้</span>
        </a>
        <a href="member_prices.php">💰 <span>ราคาสมาชิก</span></a>


        <a href="reports.php">
            📊
            <span>รายงาน</span>
        </a>


        <a href="performance.php">
            🏆
            <span>ผลงาน / KPI</span>
        </a>


        <div class="menu-label system">
            SYSTEM
        </div>


        <a href="settings.php">
            ⚙️
            <span>ตั้งค่าระบบ</span>
        </a>

    </nav>

</aside>



<!-- =========================================================
     MAIN
========================================================= -->

<main class="main">


<!-- =========================================================
     TOPBAR
========================================================= -->

<header class="topbar">

    <div>

        <h1>
            Dashboard
        </h1>

        <p>
            ภาพรวมการดำเนินงาน NSM Member Club
        </p>

    </div>


    <div class="top-actions">

        <button class="icon-button">
            🔔
        </button>

        <div class="avatar">
            A
        </div>

    </div>

</header>



<section class="content">


<!-- =========================================================
     FILTER
========================================================= -->

<form
    class="filter-bar"
    method="get"
>

    <span class="filter-label">
        แสดงข้อมูล
    </span>


    <select
        name="fy"
        onchange="this.form.submit()"
    >

        <?php

        foreach (
            ['2569', '2568', '2567', '2566']
            as $y
        ):

        ?>

            <option
                value="<?= $y ?>"
                <?= $fy == $y ? 'selected' : '' ?>
            >

                ปีงบประมาณ <?= $y ?>

            </option>

        <?php endforeach; ?>

    </select>


    <select>

        <option>
            ทุกอาคาร
        </option>

        <option>
            อาคารพระจอมเกล้า
        </option>

        <option>
            อาคารพิพิธภัณฑ์
        </option>

        <option>
            อาคารปฏิบัติการ
        </option>

    </select>


    <select>

        <option>
            ทุกเดือน
        </option>

        <option>
            ตุลาคม
        </option>

        <option>
            พฤศจิกายน
        </option>

        <option>
            ธันวาคม
        </option>

        <option>
            มกราคม
        </option>

        <option>
            กุมภาพันธ์
        </option>

        <option>
            มีนาคม
        </option>

        <option>
            เมษายน
        </option>

        <option>
            พฤษภาคม
        </option>

        <option>
            มิถุนายน
        </option>

        <option>
            กรกฎาคม
        </option>

        <option>
            สิงหาคม
        </option>

        <option>
            กันยายน
        </option>

    </select>

</form>



<!-- =========================================================
     STAT CARDS
========================================================= -->

<div class="stats">


<?php

$cards = [

    [
        'สมาชิกทั้งหมด',
        number_format($d['members']),
        'ข้อมูลจากฐานข้อมูล',
        '👥',
        'blue'
    ],

    [
        'รายได้สะสม',
        money($d['revenue']),
        'ข้อมูลจากฐานข้อมูล',
        '💰',
        'green'
    ],

    [
        'จำนวนครั้งที่ปฏิบัติงาน',
        number_format($d['work_count']),
        'ข้อมูลจากฐานข้อมูล',
        '👨‍💼',
        'orange'
    ],

    [
        'สมาชิกที่แจ้งข่าวสาร',
        number_format($d['notifications']),
        'ข้อมูลจากฐานข้อมูล',
        '📢',
        'purple'
    ]

];


foreach ($cards as $c):

?>

    <div class="stat-card">

        <div>

            <div class="stat-label">
                <?= htmlspecialchars($c[0]) ?>
            </div>

            <div class="stat-number">
                <?= $c[1] ?>
            </div>

            <div class="stat-change positive">
                <?= htmlspecialchars($c[2]) ?>
            </div>

        </div>


        <div class="stat-icon <?= htmlspecialchars($c[4]) ?>">
            <?= $c[3] ?>
        </div>

    </div>

<?php endforeach; ?>


</div>



<!-- =========================================================
     REVENUE + TARGET
========================================================= -->

<div class="grid">


<section class="card">


    <div class="card-header">

        <div>

            <div class="card-title">
                รายได้รายเดือน
            </div>

            <div class="card-subtitle">
                เปรียบเทียบรายได้จริงกับเป้าหมาย
            </div>

        </div>


        <span class="badge">
            FY <?= htmlspecialchars($fy) ?>
        </span>

    </div>


    <div class="chart-container">

        <canvas id="revenueChart"></canvas>

    </div>


</section>



<section class="card">


    <div class="card-header">

        <div>

            <div class="card-title">
                🎯 เป้าหมายรายได้
            </div>

            <div class="card-subtitle">
                NSM Member Club
            </div>

        </div>


        <span class="badge">
            FY <?= htmlspecialchars($fy) ?>
        </span>

    </div>


    <div class="target-number">

        <?= money($d['revenue']) ?>

    </div>


    <div class="target-text">

        จากเป้าหมาย
        <?= money($d['target']) ?>

    </div>


    <div class="progress">

        <div
            class="progress-bar"
            style="width:<?= min(100, $d['achievement']) ?>%"
        ></div>

    </div>


    <div class="target-row">

        <span>
            ทำได้แล้ว
        </span>

        <strong>
            <?= number_format($d['achievement'], 1) ?>%
        </strong>

    </div>


    <div class="target-row">

        <span>
            เหลืออีก
        </span>

        <strong>
            <?= money($d['remaining']) ?>
        </strong>

    </div>


    <div class="target-row">

        <span>
            เป้าหมาย/เดือน
        </span>

        <strong>
            <?= money($monthly_target) ?>
        </strong>

    </div>


</section>

</div>



<!-- =========================================================
     EMPLOYEE + BUILDING
========================================================= -->

<div class="grid">


<section class="card">


    <div class="card-header">

        <div>

            <div class="card-title">
                👨‍💼 ผลงานพนักงาน
            </div>

            <div class="card-subtitle">

                สรุปการทำงานในปีงบประมาณ
                <?= htmlspecialchars($fy) ?>

            </div>

        </div>


        <a
            class="link"
            href="#"
        >
            ดูทั้งหมด →
        </a>

    </div>



    <div class="employee-list">


        <?php if (empty($employees)): ?>


            <div class="employee">

                <div>

                    ยังไม่มีข้อมูลการปฏิบัติงาน
                    ในปีงบประมาณนี้

                </div>

            </div>


        <?php else: ?>


            <?php foreach ($employees as $e): ?>


                <div class="employee">


                    <div class="employee-info">


                        <div class="employee-avatar">

                            <?= htmlspecialchars(
                                mb_substr($e[0], 0, 1)
                            ) ?>

                        </div>


                        <div>

                            <div class="employee-name">

                                <?= htmlspecialchars($e[0]) ?>

                            </div>


                            <div class="employee-position">

                                <?= htmlspecialchars($e[1]) ?>

                            </div>

                        </div>


                    </div>


                    <div class="employee-value">


                        <strong>

                            <?= money($e[2]) ?>

                        </strong>


                        <span>

                            <?= $e[3] ?>
                            ครั้ง · แจ้งข่าว
                            <?= number_format($e[4]) ?>

                        </span>


                    </div>


                </div>


            <?php endforeach; ?>


        <?php endif; ?>


    </div>


</section>



<section class="card">


    <div class="card-header">

        <div>

            <div class="card-title">
                🏢 ผลงานตามอาคาร
            </div>

            <div class="card-subtitle">
                ภาพรวมการปฏิบัติงาน
            </div>

        </div>

    </div>



    <table class="building-table">


        <thead>

            <tr>

                <th>
                    อาคาร
                </th>

                <th>
                    ครั้ง
                </th>

                <th>
                    รายได้
                </th>

            </tr>

        </thead>


        <tbody>


        <?php if (empty($buildings)): ?>


            <tr>

                <td colspan="3">
                    ยังไม่มีข้อมูล
                </td>

            </tr>


        <?php else: ?>


            <?php foreach ($buildings as $b): ?>


                <tr>


                    <td>

                        <b>
                            <?= htmlspecialchars($b[0]) ?>
                        </b>


                        <?php if ($b[3]): ?>

                            <span class="badge green">
                                สูงสุด
                            </span>

                        <?php endif; ?>


                    </td>


                    <td class="right">

                        <?= number_format($b[1]) ?>

                    </td>


                    <td class="right">

                        <?= money($b[2]) ?>

                    </td>


                </tr>


            <?php endforeach; ?>


        <?php endif; ?>


        </tbody>


    </table>


</section>


</div>



<!-- =========================================================
     FOOTER
========================================================= -->

<div class="footer">

    NSM Member Club Management System
    · Dashboard

</div>


</section>

</main>



<!-- =========================================================
     DATA FOR CHART.JS
========================================================= -->

<script>

window.dashboardData = {

    labels: [
        'ต.ค.',
        'พ.ย.',
        'ธ.ค.',
        'ม.ค.',
        'ก.พ.',
        'มี.ค.',
        'เม.ย.',
        'พ.ค.',
        'มิ.ย.',
        'ก.ค.',
        'ส.ค.',
        'ก.ย.'
    ],

    actual:
        <?= json_encode(
            $actual,
            JSON_UNESCAPED_UNICODE
        ) ?>,

    target:
        <?= json_encode(
            $targetChart,
            JSON_UNESCAPED_UNICODE
        ) ?>,

    previous:
        <?= json_encode(
            $previous,
            JSON_UNESCAPED_UNICODE
        ) ?>,

    currentFY: <?=$fy?>,
    previousFY: <?=$prevFY?>

};

</script>



<script src="assets/js/dashboard.js"></script>


</body>

</html>