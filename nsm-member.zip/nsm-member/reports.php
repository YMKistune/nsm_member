<?php
date_default_timezone_set('Asia/Bangkok');
require_once __DIR__ . '/config/database.php';
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function money($v){return '฿'.number_format((float)$v,2);}
$monthNames=[1=>'ต.ค.',2=>'พ.ย.',3=>'ธ.ค.',4=>'ม.ค.',5=>'ก.พ.',6=>'มี.ค.',7=>'เม.ย.',8=>'พ.ค.',9=>'มิ.ย.',10=>'ก.ค.',11=>'ส.ค.',12=>'ก.ย.'];
$currentMonth=(int)date('n'); $currentYear=(int)date('Y');
$defaultFY=$currentMonth>=10?$currentYear+544:$currentYear+543;
$fy=isset($_GET['fy'])?(int)$_GET['fy']:$defaultFY;
$month=isset($_GET['month'])?(int)$_GET['month']:0;
$buildingId=isset($_GET['building_id'])?(int)$_GET['building_id']:0;
$positionId=isset($_GET['position_id'])?(int)$_GET['position_id']:0;
$employees=$pdo->query("SELECT id,name FROM employees WHERE is_active=1 ORDER BY name")->fetchAll();
$buildings=$pdo->query("SELECT id,name FROM buildings WHERE is_active=1 ORDER BY name")->fetchAll();
$positions=$pdo->query("SELECT id,name FROM positions WHERE is_active=1 ORDER BY name")->fetchAll();
$fyOptions=[];
foreach($pdo->query("SELECT DISTINCT fiscal_year FROM member_monthly_entries ORDER BY fiscal_year DESC")->fetchAll() as $r)$fyOptions[(int)$r['fiscal_year']]=true;
foreach($pdo->query("SELECT DISTINCT YEAR(work_date) y FROM employee_work_records ORDER BY y DESC")->fetchAll() as $r){$y=(int)$r['y']+544;$fyOptions[$y]=true;$fyOptions[$y-1]=true;}
foreach([$defaultFY,$defaultFY-1,$defaultFY-2,$fy] as $y)$fyOptions[$y]=true;
krsort($fyOptions);

// สมาชิก: สรุปจากรายการที่บันทึกจริง โดยใช้ applied_rate ย้อนหลัง
$memberWhere=['e.fiscal_year=?']; $memberParams=[$fy];
if($month>=1&&$month<=12){$memberWhere[]='e.fiscal_month=?';$memberParams[]=$month;}
$memberSql="SELECT i.category_name,i.label,SUM(e.quantity) quantity,SUM(CASE WHEN i.calculation_type='fixed_rate' THEN e.quantity*COALESCE(e.applied_rate,i.rate) WHEN i.calculation_type='manual_revenue' THEN COALESCE(e.revenue_override,0) ELSE 0 END) revenue FROM member_monthly_entries e JOIN member_input_items i ON i.id=e.item_id WHERE ".implode(' AND ',$memberWhere)." GROUP BY i.category_name,i.label ORDER BY i.category_name,i.sort_order,i.label";
$stmt=$pdo->prepare($memberSql);$stmt->execute($memberParams);$memberRows=$stmt->fetchAll();
$memberCount=0;$memberRevenue=0;foreach($memberRows as $r){$memberCount+=(int)$r['quantity'];$memberRevenue+=(float)$r['revenue'];}

// ผลงานพนักงาน
$startCalendar=$fy-544;$endCalendar=$startCalendar+1;
$where=['work_date>=? AND work_date<?'];$params=[sprintf('%04d-10-01',$startCalendar),sprintf('%04d-10-01',$endCalendar)];
if($month>=1&&$month<=12){$calendarMonth=$month<=3?$month+9:$month-3;$calendarYear=$month<=3?$endCalendar:$startCalendar;$from=sprintf('%04d-%02d-01',$calendarYear,$calendarMonth);$to=date('Y-m-d',strtotime($from.' +1 month'));$where=['work_date>=? AND work_date<?'];$params=[$from,$to];}
if($buildingId>0){$where[]='building_id=?';$params[]=$buildingId;}
if($positionId>0){$where[]='position_id=?';$params[]=$positionId;}
$workSql="SELECT employee_id,employee_name_snapshot employee_name,GROUP_CONCAT(DISTINCT position_snapshot ORDER BY position_snapshot SEPARATOR ', ') positions,GROUP_CONCAT(DISTINCT building_snapshot ORDER BY building_snapshot SEPARATOR ', ') buildings,COUNT(*) work_count,COALESCE(SUM(member_notifications),0) members,COALESCE(SUM(daily_sales),0) sales FROM employee_work_records WHERE ".implode(' AND ',$where)." GROUP BY employee_id,employee_name_snapshot ORDER BY sales DESC,work_count DESC,members DESC,employee_name";
$stmt=$pdo->prepare($workSql);$stmt->execute($params);$workRows=$stmt->fetchAll();
$totalWork=$totalMembers=$totalSales=0;foreach($workRows as $r){$totalWork+=(int)$r['work_count'];$totalMembers+=(int)$r['members'];$totalSales+=(float)$r['sales'];}

// อาคาร
$buildingSql="SELECT COALESCE(building_snapshot,'ไม่ระบุ') building,COUNT(*) work_count,COALESCE(SUM(member_notifications),0) members,COALESCE(SUM(daily_sales),0) sales FROM employee_work_records WHERE ".implode(' AND ',$where)." GROUP BY building_snapshot ORDER BY sales DESC,work_count DESC";
$stmt=$pdo->prepare($buildingSql);$stmt->execute($params);$buildingRows=$stmt->fetchAll();

// เป้าหมาย NSM Member Club
$target=0;$targetStmt=$pdo->prepare("SELECT COALESCE(SUM(annual_target),0) FROM revenue_targets WHERE fiscal_year=?");$targetStmt->execute([$fy]);$target=(float)$targetStmt->fetchColumn();
$targetPct=$target>0?($memberRevenue/$target*100):0;
?>
<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>รายงาน - NSM Member Club</title><link rel="stylesheet" href="assets/css/style.css"></head><body>
<aside class="sidebar"><div class="brand"><div class="brand-icon">👥</div><div><div class="brand-title">NSM Member Club</div><div class="brand-subtitle">Management System</div></div></div><nav class="menu"><div class="menu-label">MAIN MENU</div><a href="dashboard.php">🏠 <span>Dashboard</span></a><a href="member_statistics.php">👥 <span>งานสมาชิก</span></a><a href="employees.php">👨‍💼 <span>งานพนักงาน</span></a><a href="member_prices.php">💰 <span>ราคาสมาชิก</span></a><a class="active" href="reports.php">📊 <span>รายงาน</span></a><a href="performance.php">🏆 <span>ผลงาน / KPI</span></a><div class="menu-label system">SYSTEM</div><a href="settings.php">⚙️ <span>ตั้งค่าระบบ</span></a></nav></aside>
<main class="main"><header class="topbar"><div><h1>รายงาน</h1><p>สรุปข้อมูลสมาชิกและผลงานพนักงานตามช่วงเวลาที่เลือก</p></div><div class="top-actions"><button class="icon-button">🔔</button><div class="avatar">A</div></div></header><div class="content">
<form class="filter-bar" method="get"><span class="filter-label">ปีงบประมาณ</span><select name="fy"><?php foreach(array_keys($fyOptions) as $y):?><option value="<?=$y?>" <?=$fy===$y?'selected':''?>><?=$y?></option><?php endforeach;?></select><span class="filter-label">เดือน</span><select name="month"><option value="0">ทั้งปี</option><?php foreach($monthNames as $m=>$n):?><option value="<?=$m?>" <?=$month===$m?'selected':''?>><?=$n?></option><?php endforeach;?></select><span class="filter-label">ตำแหน่งงาน</span><select name="position_id"><option value="0">ทุกตำแหน่ง</option><?php foreach($positions as $p):?><option value="<?=$p['id']?>" <?=$positionId===$p['id']?'selected':''?>><?=e($p['name'])?></option><?php endforeach;?></select><span class="filter-label">อาคาร</span><select name="building_id"><option value="0">ทุกอาคาร</option><?php foreach($buildings as $b):?><option value="<?=$b['id']?>" <?=$buildingId===$b['id']?'selected':''?>><?=e($b['name'])?></option><?php endforeach;?></select><button class="icon-button" style="border-radius:8px;width:auto;padding:0 16px" type="submit">ดูรายงาน</button></form>
<div class="stats"><div class="stat-card"><div><div class="stat-label">จำนวนสมาชิก</div><div class="stat-number"><?=number_format($memberCount)?></div></div><div class="stat-icon blue">👥</div></div><div class="stat-card"><div><div class="stat-label">รายได้สมาชิก</div><div class="stat-number"><?=money($memberRevenue)?></div></div><div class="stat-icon green">💰</div></div><div class="stat-card"><div><div class="stat-label">จำนวนครั้งปฏิบัติงาน</div><div class="stat-number"><?=number_format($totalWork)?></div></div><div class="stat-icon orange">📅</div></div><div class="stat-card"><div><div class="stat-label">ยอดผลงานพนักงาน</div><div class="stat-number"><?=money($totalSales)?></div></div><div class="stat-icon purple">🏆</div></div></div>
<div class="grid"><div class="card"><div class="card-header"><div><div class="card-title">👥 รายงานสมาชิก</div><div class="card-subtitle">ข้อมูลจากงานสมาชิก ปีงบประมาณ <?=$fy?><?=($month>=1?' · '.$monthNames[$month]:' · ทั้งปี')?></div></div><span class="badge">Member</span></div><div style="overflow:auto"><table class="building-table"><thead><tr><th>ประเภท</th><th>รายการ</th><th>จำนวน</th><th class="right">รายได้</th></tr></thead><tbody><?php foreach($memberRows as $r):?><tr><td><?=e($r['category_name'])?></td><td><?=e($r['label'])?></td><td><?=number_format($r['quantity'])?></td><td class="right"><?=money($r['revenue'])?></td></tr><?php endforeach;?><?php if(!$memberRows):?><tr><td colspan="4" style="text-align:center">ยังไม่มีข้อมูลสมาชิก</td></tr><?php endif;?></tbody></table></div></div>
<div class="card"><div class="card-header"><div><div class="card-title">🎯 เป้าหมาย NSM Member Club</div><div class="card-subtitle">เทียบรายได้สมาชิกกับเป้าหมายของปี</div></div></div><div style="padding:18px 0"><div class="stat-label">เป้าหมายรายปี</div><div class="stat-number"><?=money($target)?></div><div class="stat-label" style="margin-top:16px">ทำได้ <?=money($memberRevenue)?> · <?=number_format($targetPct,1)?>%</div><div style="height:12px;background:#eee;border-radius:8px;overflow:hidden;margin-top:10px"><div style="width:<?=min(100,max(0,$targetPct))?>%;height:100%;background:var(--primary,#2563eb)"></div></div></div></div></div>
<div class="grid"><div class="card"><div class="card-header"><div><div class="card-title">🏆 รายงานผลงานพนักงาน</div><div class="card-subtitle">ยอดผลงานไม่ถูกรวมกับรายได้ฝ่ายสมาชิก</div></div><span class="badge">Performance</span></div><div style="overflow:auto"><table class="building-table"><thead><tr><th>อันดับ</th><th>พนักงาน</th><th>ตำแหน่ง</th><th>อาคาร</th><th>ครั้ง</th><th>สมาชิก</th><th class="right">ยอดผลงาน</th></tr></thead><tbody><?php foreach($workRows as $i=>$r):?><tr><td><strong><?=$i+1?></strong></td><td><?=e($r['employee_name'])?></td><td><?=e($r['positions']?:'-')?></td><td><?=e($r['buildings']?:'-')?></td><td><?=number_format($r['work_count'])?></td><td><?=number_format($r['members'])?></td><td class="right"><?=money($r['sales'])?></td></tr><?php endforeach;?><?php if(!$workRows):?><tr><td colspan="7" style="text-align:center">ยังไม่มีข้อมูลผลงาน</td></tr><?php endif;?></tbody></table></div></div>
<div class="card"><div class="card-header"><div><div class="card-title">🏢 สรุปตามอาคาร</div><div class="card-subtitle">รวมทุกวันที่พนักงานไปปฏิบัติงานในอาคารนั้น</div></div></div><div style="overflow:auto"><table class="building-table"><thead><tr><th>อาคาร</th><th>ครั้ง</th><th>สมาชิก</th><th class="right">ยอดผลงาน</th></tr></thead><tbody><?php foreach($buildingRows as $r):?><tr><td><?=e($r['building'])?></td><td><?=number_format($r['work_count'])?></td><td><?=number_format($r['members'])?></td><td class="right"><?=money($r['sales'])?></td></tr><?php endforeach;?><?php if(!$buildingRows):?><tr><td colspan="4" style="text-align:center">ยังไม่มีข้อมูลอาคาร</td></tr><?php endif;?></tbody></table></div></div></div>
<div class="card"><div class="card-header"><div><div class="card-title">ℹ️ หมายเหตุของรายงาน</div><div class="card-subtitle">แยกข้อมูลสองส่วนเพื่อไม่ให้ยอดปะปนกัน</div></div></div><div class="footer">รายได้จากงานสมาชิกใช้สำหรับรายงาน NSM Member Club ส่วนยอดผลงานพนักงานใช้สำหรับการวิเคราะห์ผลงานและ KPI เท่านั้น</div></div>
</div></main></body></html>
